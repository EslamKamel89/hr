function addContact() {
    $("#input_contacts").append(`<div class="form-group col-md-6">
                                        <label for="exampleInputEmail111">Name</label>
                                        <input type="text" value=""
                                            class="form-control"
                                            id="exampleInputEmail111" name="contact_name[]"
                                            placeholder="Enter contact name" autofocus autocomplete="">

                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="exampleInputEmail111">Value</label>
                                        <input type="text" value=""
                                            class="form-control "
                                            id="exampleInputEmail111" name="contact_value[]" placeholder="Enter contact  value"
                                            autofocus autocomplete="">

                                    </div>`);
}

function addLicense() {
    $("#licenses").append(`
         <div class="form-group col-md-12">
                                        <label for="exampleInputEmail111">License</label>
                                        <input type="text" value="" class="form-control" id="exampleInputEmail111"
                                            name="license_name[]" placeholder="Enter License name" autofocus
                                            autocomplete="">

                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="exampleInputEmail111">Start date</label>
                                        <input type="date" value="" class="form-control"
                                            id="exampleInputEmail111" name="license_start[]"
                                            placeholder="Enter license start" autofocus autocomplete="">
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label for="exampleInputEmail111">End date</label>
                                        <input type="date" value="" class="form-control"
                                            id="exampleInputEmail111" name="license_end[]"
                                            placeholder="Enter license start" autofocus autocomplete="">
                                    </div>
                                    `);
}

function addActivity() {
    $("#activities").append(`
        <div class="form-group col-md-9">
                                            <label for="exampleInputEmail111">Name</label>
                                            <input type="text" value="" class="form-control"
                                                id="exampleInputEmail111" name="activity['name'][]"
                                                placeholder="Enter activity name" autofocus autocomplete="">
                                        </div>
                                    `);
}
function addMember() {
    $("#members").append(`
         <div class="form-group col-md-9">
                                            <label for="exampleInputEmail111">National Id</label>
                                            <input type="text" value="" class="form-control"
                                                id="exampleInputEmail111" name="member['national_id'][]"
                                                placeholder="Enter national id" autofocus autocomplete="">

                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="exampleInputEmail111">Member name</label>
                                            <input type="text" value="" class="form-control"
                                                id="exampleInputEmail111" name="member['name'][]"
                                                placeholder="Enter member name" autofocus autocomplete="">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="exampleInputEmail111">Member nationality</label>
                                            <select name="" class="form-control" id="">
                                                <option value="">Please select nationality</option>
                                                <option value="">Egypt</option>
                                                <option value="">UAE</option>
                                                <option value="">India</option>
                                                <option value="">Pakistan</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="exampleInputEmail111">Role</label>
                                            <input type="text" value="" class="form-control"
                                                id="exampleInputEmail111" name="member['role'][]"
                                                placeholder="Enter member role" autofocus autocomplete="">
                                        </div>

                                        <div class="form-group col-md-6">
                                            <label for="exampleInputEmail111">Percent</label>
                                            <input type="text" value="" class="form-control"
                                                id="exampleInputEmail111" name="member['percent'][]"
                                                placeholder="Enter member percent" autofocus autocomplete="">
                                        </div>
                                    `);
}
