function checkOpen(name){
$("#check_"+name).slideToggle(200);
}
